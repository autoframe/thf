<?php
declare(strict_types=1);

namespace Autoframe\Components\Arr;

class AfrArrCollectionClass implements AfrArrCollectionInterface
{
    use AfrArrCollectionTrait;
}